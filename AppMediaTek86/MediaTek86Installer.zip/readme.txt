le programme s'installe via le fichier MediaTek86Installer.msi
ajouter sur serveur MySQL la BDD mediatek86 via le fichier mediatek86.sql